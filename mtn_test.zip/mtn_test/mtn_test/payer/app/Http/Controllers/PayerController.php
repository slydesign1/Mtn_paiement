<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use PatricPoba\MtnMomo\MtnConfig;
use PatricPoba\MtnMomo\MtnCollection;
use App\Models\Payer;
use Cookie;

class PayerController extends Controller
{
    
public function index()
{
        return view('payer.smspayer');
}

    

    public function mtn(Request $request)
{
    $mtn="mtn";
    $objet = $request->objet;// L'objet
    $prix = $request->prix; // montant
    $nom = $request->nom;
    $numero = $request->numero;


    $config = new MtnConfig([ 
        // mandatory credentials
        'baseUrl'               => 'https://ericssonbasicapi1.azure-api.net', 
        'currency'              => 'XOF', 
        'targetEnvironment'     => 'mtnivorycoast', 
    
        // collection credentials
        "collectionApiSecret"   => '', //API key
        "collectionPrimaryKey"  => '', //ocpim
        "collectionUserId"      => ''// Api user
    ]);
    
    
    $collection = new MtnCollection($config); 
    // $indice = '225';
    $params = [
        "mobileNumber"      => '2250586953562',//$indice.  $numero,  // "mobileNumber"      => $indice. '0586953562', 
        "amount"            => '10', //$prix,
        "externalId"        => '774747234',
        "payerMessage"      => 'some note',
        "payeeNote"         => '1212'
    ];
    
    $transactionId = $collection->requestToPay($params);

    // echo $transactionId; 
    // echo $indice; 
    
    $transaction = $collection->getTransaction($transactionId);

    

    // $ion =$transaction->financialTransactionId;
    $ion1 =$transaction->externalId;
    $ion2 =$transaction->amount;
    $ion3 =$transaction->payer;
    // // $ion4 = $transaction->payer->payerpartyId;
    $ion5 =$transaction->currency;
    $ion6 =$transaction->status;
    //dd($transaction);
    
    return view('retour.lastpart',[
            'mtn'=> $mtn,
            'ion6'=>$ion6,
            'transactionId'=>$transactionId,
            'objet'=>$objet,
            'numero'=>$numero,
            'prix'=>$prix,
            'nom'=>$nom,
            
        ]);


}
public function mtnretour(Request $request)
{
    $mtn="mtn";
    $transactionId = $request->transactionId;
    
    $objet = $request->objet;
    $numero = $request->numero;
    $prix = $request->prix;
    $nom = $request->nom;
   



    $config = new MtnConfig([ 
        // mandatory credentials
        'baseUrl'               => 'https://ericssonbasicapi1.azure-api.net', 
        'currency'              => 'XOF', 
        'targetEnvironment'     => 'mtnivorycoast', 
    
        // collection credentials
        "collectionApiSecret"   => '', 
        "collectionPrimaryKey"  => '', 
        "collectionUserId"      => ''
    ]);
    
    
    $collection = new MtnCollection($config); 
    
   
    
   //55f8fb98-3917-4202-944b-b3fc3b5afb64  
    
    $transaction = $collection->getTransaction($transactionId);

    // var_dump($transaction);

    // $ion1 =$transaction->externalId;
    // $ion2 =$transaction->amount;
    // $ion3 =$transaction->payer;
    // // $ion4 = $transaction->payer->payerpartyId;
    // $ion5 =$transaction->currency;
    $ion6 =$transaction->status;
    // echo $transacstaus6;
    
  
    // base de donnée
    // if($ion6 == "SUCCESSFUL"){
    //     $payer = new Payer;

    //     $payer->reseau= $mtn;
    //     $payer->volume_sms=  $objet;
    //     $payer->trans=  $transactionId;
    //     $payer->status=  $ion6;
    //     $payer->numero=  $numero;
    //     $payer->prix=  $prix;
    //     $payer->nom= $nom;
    //     $payer->save();
          
    // }
    // if($ion6 == "FAILED"){
    //     $payers = new Payer;
       
    //     $payers->reseau= $mtn;
    //     $payers->volume_sms= $objet;
    //     $payers->trans=  $transactionId;
    //     $payers->status=  $ion6;
    //     $payers->numero=  $numero;
    //     $payers->prix=  $prix;
    //     $payers->nom= $nom;
    //     $payers->save();

           
    // }
    
    return view('retour.lastpart',[
        'mtn'=> $mtn,
        'ion6'=>$ion6,
        'transactionId'=>$transactionId,
        'objet'=>$objet,
        'numero'=>$numero,
        'prix'=>$prix,
        'nom'=>$nom,
        
    ]);

}


}
