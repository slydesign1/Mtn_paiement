<?php return array (
  'facade/ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Facade\\Ignition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Facade\\Ignition\\Facades\\Flare',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'fruitcake/laravel-cors' => 
  array (
    'providers' => 
    array (
      0 => 'Fruitcake\\Cors\\CorsServiceProvider',
    ),
  ),
  'ibracilinks/orange-money' => 
  array (
    'providers' => 
    array (
      0 => 'Ibracilinks\\OrangeMoney\\Providers\\OrangeMoneyServiceProvider',
    ),
    'aliases' => 
    array (
      'OrangeMoney' => 'Ibracilinks\\OrangeMoney\\Facades\\OrangeMoney',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'patricpoba/mtn-momo-api-php' => 
  array (
    'providers' => 
    array (
      0 => 'PatricPoba\\MtnMomo\\MtnMomoServiceProvider',
    ),
    'aliases' => 
    array (
      'MtnMomoCollection' => 'PatricPoba\\MtnMomo\\Facades\\MtnCollectionFacade',
      'MtnMomoRemittance' => 'PatricPoba\\MtnMomo\\Facades\\MtnRemittanceFacade',
      'MtnMomoDisbursement' => 'PatricPoba\\MtnMomo\\Facades\\MtnDisbursementFacade',
    ),
  ),
);